# Deploying prashantmishra.co.in

The site is plain HTML, so there is nothing to build. Upload this folder as-is.

## Fastest route: Cloudflare Pages (free)
1. Create a free account at cloudflare.com and choose Workers & Pages > Create > Pages > Upload assets.
2. Name the project, drag in this folder (index.html, favicon.svg, og-image.png, robots.txt, sitemap.xml) and deploy.
3. Open the project > Custom domains > Set up a domain > prashantmishra.co.in.
4. Cloudflare shows the DNS records to add. Either move your domain's nameservers to Cloudflare (easiest), or add the CNAME it gives you at your registrar's DNS panel. Repeat for www.prashantmishra.co.in and set it to redirect to the main domain.
5. HTTPS is issued automatically within a few minutes.

## Alternatives
- Netlify: app.netlify.com/drop, drag the folder, then Domain settings > Add custom domain.
- GitHub Pages: push the files to a repo (for example iprashantmishra/prashantmishra.co.in), enable Pages, add a file named CNAME containing prashantmishra.co.in, then point DNS to GitHub.

## Email (me@prashantmishra.co.in)
The website only links to this address. You still need a mailbox behind it:
- Free forwarding to your Gmail: Cloudflare Email Routing (if DNS is on Cloudflare), ImprovMX or your registrar's forwarding.
- Full mailbox: Google Workspace or Zoho Mail (Zoho has a free tier).
Add the MX/SPF records the provider gives you. Test by emailing yourself from another account.

## After launch checklist
- Send the link to yourself on WhatsApp and check the preview card shows the image.
- Test the WhatsApp and email buttons on your phone.
- Update the LinkedIn Featured section and the CV header with prashantmishra.co.in.
- Submit https://prashantmishra.co.in/ in Google Search Console.
